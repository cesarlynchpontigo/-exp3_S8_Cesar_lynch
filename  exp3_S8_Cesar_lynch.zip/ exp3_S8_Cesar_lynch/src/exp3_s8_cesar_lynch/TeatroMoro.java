/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exp3_s8_cesar_lynch;

/**
 *
 * @author sd
 */
import java.util.Scanner;

public class TeatroMoro {

    static Scanner scanner = new Scanner(System.in);
    static Cliente[] clientes = new Cliente[10];
    static int cantidadClientes = 0;

    public static void main(String[] args) {
        int opcion;
        do {
            mostrarMenu();
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    comprarEntradas();
                    break;
                case 2:
                    ver();
                    break;
                case 3:
                    eliminarOActualizarDatos();
                    break;
                case 4:
                    System.out.println("Gracias por utilizar el sistema. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción inválida. Por favor, seleccione una opción válida.");
            }
        } while (opcion != 4);
    }

    static void mostrarMenu() {
        System.out.println(" Teatro Moro");
        System.out.println("1. Comprar entrradas");
        System.out.println("2. Ver datos");
        System.out.println("3. Eliminar o actializar");
        System.out.println("4. Salir");
    }

    static void comprarEntradas() {
        System.out.print("Ingrese ID_ ");
        String id = scanner.nextLine();
        System.out.print("Cuántas entradas necesita (Máximo 2 por id): ");
        int cantidadEntradas = scanner.nextInt();

     // no entendi profesor la unica forma que tengo para cruzar informacion es el ID asignado??
        Cliente clienteExistente = buscarClientePorId(id);
        if (clienteExistente != null) {
            if (clienteExistente.getEntradas() + cantidadEntradas > 2) {
                System.out.println("solo 2 entradas por ID ERROR");
                return;
            }
        }

     // Apliacar descuento segun  estud, terecera edad
        System.out.print("Es estudiante (Sí-No-): ");
        String tipoCliente = scanner.next().toLowerCase();
        double precioEntrada;
        double descuento;
        if (tipoCliente.equals("si")) {
            precioEntrada = 2000;
            descuento = 0.1;
        } else {
            precioEntrada = 3000;
            descuento = 0.3;
        }

        // valor segun descuento asignado
        double precioTotal = precioEntrada * cantidadEntradas * (1 - descuento);

   //
        Cliente cliente = new Cliente(id, cantidadEntradas, precioTotal);
        clientes[cantidadClientes++] = cliente;
        System.out.println("Compra realizada con éxito. Total a pagar: " + precioTotal);
    }

    static void ver() {
        System.out.print("Ingrese su ID: ");
        String id = scanner.nextLine();

        // Buscar al cliente por su ID ,  A eso se refiere a cruzar informacion ? 
        Cliente cliente = buscarClientePorId(id);
        if (cliente != null) {
            System.out.println("ID " + cliente.getId() + ", Entradas " + cliente.getEntradas() + ", Precio total: " + cliente.getPrecioTotal());
            System.out.print(" Desea comprar más entradas (Sí/No): ");
            String comprarMas = scanner.next().toLowerCase();
            if (comprarMas.equals("si")) {
                comprarEntradas();
            }
        } else {
            System.out.println(" no encontrado Error");
        }
    }

    static void eliminarOActualizarDatos() {
        System.out.print("Ingrese su ID , ");
        String id = scanner.nextLine();

        // Buscar al cliente por su ID Cruzar ??? INFORMACION NO ENTIENDO PROFE 
        Cliente cliente = buscarClientePorId(id);
        if (cliente != null) {
            System.out.println("ID: " + cliente.getId() + ", Entradas  " + cliente.getEntradas() + ", Precio total " + cliente.getPrecioTotal());
            System.out.print(" los datos son correctos (Sí/No): ");
            String confirmar = scanner.next().toLowerCase();
            if (confirmar.equals("no")) {
                return;
            } else {
                System.out.print("¿Desea eliminar  presione (e) o actualizar presiones (a)  ");
                String opcion = scanner.next().toLowerCase();
                if (opcion.equals("e")) {
                    eliminarCliente(cliente);
                    System.out.println("Datos eliminados ");
                } else if (opcion.equals("a")) {
                    System.out.print("Ingrese la nueva cantidad de entradas ");
                    int nuevaCantidad = scanner.nextInt();
                    cliente.setEntradas(nuevaCantidad);
                    System.out.println("Datos actualizados correctamente,");
                } else {
                    System.out.println("Opción inválida Error");
                }
            }
        } else {
            System.out.println("Cliente no encontrado Error");
        }
    }

    static Cliente buscarClientePorId(String id) {
        for (int i = 0; i < cantidadClientes; i++) {
            if (clientes[i].getId().equals(id)) {
                return clientes[i];
            }
        }
        return null;
    }

    static void eliminarCliente(Cliente cliente) {
        for (int i = 0; i < cantidadClientes; i++) {
            if (clientes[i].getId().equals(cliente.getId())) {
                for (int j = i; j < cantidadClientes - 1; j++) {
                    clientes[j] = clientes[j + 1];
                }
                cantidadClientes--;
                break;
            }
        }
    }
}

class Cliente {
    private String id;
    private int entradas;
    private double precioTotal;

    public Cliente(String id, int entradas, double precioTotal) {
        this.id = id;
        this.entradas = entradas;
        this.precioTotal = precioTotal;
    }

    public String getId() {
        return id;
    }

    public int getEntradas() {
        return entradas;
    }

    public void setEntradas(int entradas) {
        this.entradas = entradas;
    }

    public double getPrecioTotal() {
        return precioTotal;
    }
}
